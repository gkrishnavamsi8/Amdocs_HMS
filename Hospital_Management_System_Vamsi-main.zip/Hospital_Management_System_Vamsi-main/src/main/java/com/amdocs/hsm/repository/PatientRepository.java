package com.amdocs.hsm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.amdocs.hsm.model.*;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long>{

}