package com.amdocs.hsm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HSMApplication {

	public static void main(String[] args) {
		SpringApplication.run(HSMApplication.class, args);
		System.out.println("Springboot Started (HSM)");
	}

}
